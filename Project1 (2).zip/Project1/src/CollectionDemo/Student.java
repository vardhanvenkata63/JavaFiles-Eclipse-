package CollectionDemo;

import java.util.LinkedList;
import java.util.Scanner;

public class Student {
	private String name;
	private String address;
	private int gpa;
	static LinkedList<Student> obj= new LinkedList<Student>();
	static Scanner scr=new Scanner(System.in);
	public Student(String name,String add,int gpa) {
		super();
		this.name=name;
		this.address=add;
		this.gpa=gpa;
	}
	public String getName() {
		return this.name;
	}
	public String getAddress() {
		return this.address;
	}
	public int getGpa() {
		return this.gpa;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<=3;i++) {
			System.out.println("Enter Name:");
			String name=scr.next();
			
			System.out.println("Enter Address:");
			String addr=scr.next();
			
			System.out.println("Enter Gpa:");
			int gpa=scr.nextInt();
			obj.addLast(new Student(name,addr,gpa));
		}
		System.out.println(obj);
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", address=" + address + ", gpa=" + gpa + "]";
	}

}
