package OOPSDemo;
class Car{
	String name="BMW";
	String model="C CLass";
	String FuelType="Diesel";
	String speed="240kmph";
}
public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car c1=new Car();
		System.out.println(c1.name);
		System.out.println(c1.model);
		System.out.println(c1.FuelType);
		System.out.println(c1.speed);
		
	}

}
