package com.example;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestUser {
	public static void main(String [] args) {
		Resource rs=new ClassPathResource("applicationContext.xml");
		BeanFactory factory=new XmlBeanFactory(rs);
		//Ioc Container we can implement in 2 ways using applicationContext and BeanFactory
		//ApplicationContext context =  new ClassPathXmlApplicationContext("applicationContext.xml");  
		
		User user = (User) factory.getBean("userBean");
		user.display();
	}
}
