import java.io.FileWriter;
import java.io.IOException;

public class Demo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String msg="Happy now";
		FileWriter f;
		//FileWriter file=new FileWriter("C:\\Users\\user52\\eclipse-workspace\\TrainTicket\\src\\main\\java\\sample.txt");
		//file.append('a');
		f=new FileWriter("C:\\Users\\user52\\eclipse-workspace\\TrainTicket\\src\\main\\java\\sample.txt");
		f.write(msg);
		f.close();
		//file.close();
	}

}
