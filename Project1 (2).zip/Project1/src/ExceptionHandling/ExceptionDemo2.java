package ExceptionHandling;

public class ExceptionDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name=null;
		try {
			System.out.println(name.length());
		}
		catch(NullPointerException ex) {
			//ex.printStackTrace();
			System.out.println(ex.toString());
		}
	}

}
