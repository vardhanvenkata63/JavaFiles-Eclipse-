package EncapsulationDemo;

public class EncapsulationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User u1=new User();
		u1.setUserName("Vardhan");
		u1.setPassword("vardhan1743");
		User u2=new User();
		u2.setUserName("Venkata");
		u2.setPassword("venkat143");
		
		System.out.println("UserName:"+u1.getUserName()+"\nPassword:"+u1.getPassword());
		System.out.println("\nUserName:"+u2.getUserName()+"\nPassword:"+u2.getPassword());
	}

}
