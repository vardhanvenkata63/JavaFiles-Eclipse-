package AccessModifiersDemo;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Demo1.number1);
		//We can access the public variable of other class
		//System.out.println(Demo1.number2);
		//We cannot access the private variable of other class
		
	}

}
