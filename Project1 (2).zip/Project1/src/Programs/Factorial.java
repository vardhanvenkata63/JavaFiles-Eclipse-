package Programs;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number;
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter Number:");
		number=scr.nextInt();
		int fact=1;
		for(int i=number;i>0;i--) {
			fact=fact*i;
		}
		System.out.println("Factorial of "+number+" is: "+fact);
		scr.close();
	}

}
