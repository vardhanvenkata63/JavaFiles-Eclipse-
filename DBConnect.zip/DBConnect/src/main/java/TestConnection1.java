import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class TestConnection1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sampledb","root", "admin");
			Statement stmt=con.createStatement();
			stmt.executeUpdate("insert into student values(7,117,'gojo',76,21)");
			System.out.println("Inserted Succesfully");
			ResultSet rs=stmt.executeQuery("select * from student");
			System.out.println("Id"+" "+"R.no"+" Name"+" "+"marks "+" "+"Age");
			while(rs.next()) {
				System.out.println(rs.getInt(1)+"  "+rs.getInt(2)+"  "+rs.getString(3)+"  "+rs.getInt(4)+"   "+rs.getInt(5));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
