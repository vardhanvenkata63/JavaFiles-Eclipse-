package CollectionDemo;

import java.util.HashSet;
import java.util.Set;

public class SetDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> s=new HashSet<String>();
		//WE cannot instantiate Set because it is a interface so we use hashset
		s.add("john");
		s.add("jack");
		s.add("jill");
		s.add("john");
		//Set will not take duplicate values.
		System.out.println(s);
		
	}

}
