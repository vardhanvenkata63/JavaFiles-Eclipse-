package CollectionDemo;

import java.util.Iterator;
import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Integer> s1=new Stack<Integer>();
		s1.add(10);
		s1.add(50);
		s1.add(80);
		s1.add(57);
		Iterator it=s1.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("---------------");
		System.out.println("The size is:"+s1.size());
		System.out.println("---------------");
		s1.pop();
		Iterator it1=s1.iterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
		System.out.println("The peek value is: "+s1.peek());
		
		System.out.println("The size is:"+s1.size());
	}

}
