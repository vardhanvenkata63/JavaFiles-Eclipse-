package InterfaceDemo;
interface Int1{
	void sample();
}
interface Int2 extends Int1{
	void show();
}
public class InterfaceDemo2 implements Int2{

	public static void main(String[] args) {
		InterfaceDemo2 i = new InterfaceDemo2();
		i.show();
		i.sample();

	}

	@Override
	public void sample() {
		System.out.println("Sample Method");
	}

	@Override
	public void show() {
System.out.println("The show methodd");		
	}

}
