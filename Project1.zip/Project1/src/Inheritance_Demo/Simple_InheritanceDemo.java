package Inheritance_Demo;
class A{
	int num=100;
}
class B extends A{
	void display() {
		System.out.println("Parent's attribute is: "+num);
	}
	
}
public class Simple_InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Simple Inheritance Demo");
		B b=new B();
		b.display();
	}

}
