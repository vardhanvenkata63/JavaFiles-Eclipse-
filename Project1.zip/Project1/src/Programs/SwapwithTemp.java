package Programs;

import java.util.Scanner;

public class SwapwithTemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter Number1:");
		int number1=scr.nextInt();
		System.out.println("Enter Number2:");
		int number2=scr.nextInt();
		int temp;
		System.out.println("Before Swapping "+number1+" and "+number2);
		temp=number2;
		number2=number1;
		number1=temp;
		System.out.println("After Swapping "+number1+" and "+number2);
		scr.close();
	}

}
