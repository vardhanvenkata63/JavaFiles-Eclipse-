package ExceptionHandling;

public class exceptionDemo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=90;
		String name=null;
		try {
			System.out.println(num/0);
			System.out.println(name.length());
		}
		catch(Exception e) {
			System.out.println(num/(0+1));
			System.out.println(e.getMessage());
			System.out.println(e.toString());
			e.printStackTrace();
			System.out.println("I am Null");
		}
	}

}
