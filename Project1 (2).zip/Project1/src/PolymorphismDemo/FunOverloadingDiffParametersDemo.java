package PolymorphismDemo;
class Cal{
	int add(int x,int y) {
		return x+y;
	}
	int add(int x,int y,int z) {
		return x+y+z;
	}
}
public class FunOverloadingDiffParametersDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cal c=new Cal();
		System.out.println("Polymorphism Demo\n->function overloading with same return type but with different no.of parameters");
		System.out.println(c.add(101,110));
		System.out.println(c.add(134,987,2892));
	}

}
