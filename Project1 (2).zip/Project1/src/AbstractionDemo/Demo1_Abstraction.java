package AbstractionDemo;
abstract class A{
	int num=90;
	void display() {
		System.out.println(num);
	}
	abstract void cal();
}
public class Demo1_Abstraction extends A {
	public void cal() {
		System.out.println("10% of "+num+" is : "+num*10/100);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo1_Abstraction d=new Demo1_Abstraction();
		d.display();
		d.cal();
	}

}
