package PolymorphismDemo;
class Cal1{
	int add(int x,int y) {
		return x+y;
	}
	double add(double x,double y) {
		return x+y;
	}
}
public class Fun_OverloadingDiffdatatypeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cal1 c=new Cal1();
		System.out.println("Polymorphism Demo\n->overloading fucntion with same no of parameters with different data type");
		System.out.println(c.add(101,110));
		System.out.println(c.add(134.89,783.36));
	}

}
