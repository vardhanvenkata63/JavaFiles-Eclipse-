package ExceptionHandling;

public class exceptionDemo10 {
	static boolean checkAge(int age) {
		if(age<18) {
			throw new ArithmeticException("Age should be greater than 18");
		}
		else {
			return true;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age1=30;
		int age2=14;
		try {
			if(checkAge(age2)) {
				System.out.println("YOu are eligible fro vote");
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		try {
			if(checkAge(age1)) {
				System.out.println("YOu are eligible for vote");
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
