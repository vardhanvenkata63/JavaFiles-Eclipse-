package InterfaceDemo;
interface sample{
	abstract void display();
	void calculate();
	/*void sample() {
		System.out.println("Interface cannot have concrete methods but abstract class can have concrete methods");
	}
	*/
}
public class InterfaceDemo implements sample {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceDemo i=new InterfaceDemo();
		i.calculate();
		i.display();
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("This is the message from display");
	}

	@Override
	public void calculate() {
		// TODO Auto-generated method stub
		System.out.println("This is the message from calculate");
	}

}
