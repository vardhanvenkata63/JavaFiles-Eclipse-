
public class HelloWorld {
	public static void main(String[] args) {
	System.out.println("Hello World!,Welcome to Java World");
	System.out.println(10+30);
	}
}
