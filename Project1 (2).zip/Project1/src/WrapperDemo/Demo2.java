package WrapperDemo;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Character ch='a';
		char c=ch;
		System.out.println(ch);
		System.out.println(c);
	}

}
