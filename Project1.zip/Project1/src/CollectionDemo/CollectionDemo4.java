package CollectionDemo;

import java.util.ArrayList;
import java.util.Iterator;

public class CollectionDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> a = new ArrayList<String>();
		a.add("Vardhan");
		a.add("Shraadha");
		a.add("harsha");
		a.add("Neha");
		a.add("siren");
		a.add("Roshini");
		Iterator it=a.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
