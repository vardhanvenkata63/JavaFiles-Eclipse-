package OOPSDemo;
class Employee{
	int id;
	String name;
	int salary;
	Employee()
	{
		id=6111;
		name="venkata";
		salary=29000;
	}
	void display() {
		System.out.println("Employee Id:"+id+"\nEmployee Name:"+name+"\nSalary:"+salary);
	}
}

public class ConstructorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1=new Employee();
		e1.display();
	}

}
