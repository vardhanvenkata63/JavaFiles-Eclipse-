package OOPSDemo;
class Customer{
	int cus_id;
	String cus_name;
	int balance;
	Customer(){
		System.out.println("Default Constructor");
	}
	Customer(int cid,String cname,int bal){
		this.cus_id=cid;
		this.cus_name=cname;
		this.balance=bal;
	}
	void display() {
		System.out.println("Customer ID: "+cus_id+"\nCustomerName: "+cus_name+"\nCustomer Balance: "+balance+"\n");
	}
}
public class CustomerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c1=new Customer(601,"Ganesh",1900);
		c1.display();
		Customer c2=new Customer(602,"Shyam",98900);
		c2.display();
		Customer c3=new Customer(603,"Sufia",19800);
		c3.display();
	}
}
