package ExceptionHandling;

public class exceptionDemo7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String msg="Hello";
		try {
			System.out.println(1);
			try {
				System.out.println(2);
				System.out.println(3);
				System.out.println(msg.charAt(7));
				System.out.println(4);
			}catch(StringIndexOutOfBoundsException ex) {
				System.out.println(ex);
				System.out.println(4);
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}

}
