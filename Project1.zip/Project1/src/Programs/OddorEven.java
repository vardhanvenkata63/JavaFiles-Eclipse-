package Programs;

import java.util.Scanner;

public class OddorEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number;
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter Number:");
		number=scr.nextInt();
		if(number%2==0)
			System.out.println("Entered Number is Even");
		else
			System.out.println("Entered Number is Odd");
		scr.close();
	}

}
