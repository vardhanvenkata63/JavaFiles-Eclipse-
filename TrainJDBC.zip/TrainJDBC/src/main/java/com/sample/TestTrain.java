package com.sample;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTrain {
	public static void main(String args[]) {
	ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
	
	TrainDAO t=(TrainDAO) context.getBean("trainDAO");
	int result=t.insertTrain(new Train(1001,"Delhi Express","Delhi","Bangalore",1250));
	System.out.println(result);
	
	int result1=t.insertTrain(new Train(1002,"Andhra Express","Delhi","Hyderabad",1550));
	System.out.println(result1);
	
	int result2=t.insertTrain(new Train(1003,"Tirumala Express","Vizag","Tirupathi",1970));
	System.out.println(result2);
	
	int result3=t.insertTrain(new Train(1004,"Vishaka Express","Vizag","Vijayawada",1270));
	System.out.println(result3);
	
	int result4=t.updateTrain(new Train(1002,"AP Express","Delhi","Vijayawada",1470));
	System.out.println(result4);
	
	int result5=t.deleteTrain(new Train(1004,"Vishaka Express","Vizag","Vijayawada",1270));
	System.out.println(result5);
	
}
}

