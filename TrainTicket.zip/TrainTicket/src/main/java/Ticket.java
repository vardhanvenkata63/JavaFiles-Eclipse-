import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

class PassengerComp implements Comparator<Passenger>{

	public int compare(Passenger o1, Passenger o2) {
		// TODO Auto-generated method stub
		return o1.getName().compareTo(o2.getName());
	}

	
}
public class Ticket extends Train{
	private String pnr;
	private LocalDate travelDate;
	static private int counter=100;
	private Train train;
	private HashMap<Passenger,Double> passengers=new HashMap<Passenger,Double>();
	private List<Passenger> passenger=new ArrayList<Passenger>();
	public String getPnr() {
		return pnr;
	}
	public void setPnr(String pnr) {
		this.pnr = pnr;
	}
	public LocalDate getTravelDate() {
		return travelDate;
	}
	public void setTravelDate(LocalDate travelDate) {
		this.travelDate = travelDate;
	}
	public int getCounter() {
		return counter;
	}
	public  void setCounter(int counter) {
		this.counter = counter;
	}
	public Train getTrain() {
		return train;
	}
	public void setTrain(Train train) {
		this.train = train;
	}
	public HashMap<Passenger,Double> getPassengers() {
		return passengers;
	}
	public void setPassengers(HashMap<Passenger,Double> passengers) {
		this.passengers = passengers;
	}
	//The ticket methods
	public Ticket(LocalDate traveldate,Train train) {
		this.travelDate=traveldate;
		this.train=train;
	}
	public String generatePNR() {
		String pnrstr="";
		String src=train.getSource();
		String dest=train.getDestination();
		//String pattern="yyyy-mm-dd";
		String[] date1=travelDate.toString().split("-");
		//DateFormat df=new SimpleDateFormat(pattern);
		pnrstr=src.charAt(0)+""+dest.charAt(0)+"_"+date1[0]+date1[1]+date1[2]+"_"+counter;
		counter++;
		return pnrstr;
		
		//this method will generate the PNR number for the ticket.
	}
	double calcPassengerFare(Passenger ob)
	{
		double price = 0.0;
		double ticketPrice1=train.getTicketPrice();
		if(ob.getAge()<=12)
		{
			price=ticketPrice1-(ticketPrice1/2);
			//System.out.println("THE TIcket price is "+price);
		}
		else if(ob.getAge()>=60)
		{
			price=ticketPrice1-(0.6*ticketPrice1);
			//System.out.println("The ticket price for above 60 is "+price);
		}
		else if(ob.getGender()=='F'||ob.getGender()=='f')
		{
				price=ticketPrice1-(ticketPrice1/4);
				//System.out.println("The ticket Price for gender femaale is "+price);
		}
		return price;
	}
	void addPassenger(String name,int age,char gender)
	{
		Passenger ob=new Passenger(name,age,gender);
		passengers.put(ob,calcPassengerFare(ob));
		passenger.add(ob);
	}
	double CalculateTotalTicketFare()
	{
		double Totalprice=0;
		for(Double p:passengers.values())
		{
			Double value=p;
			Totalprice+=value;
		}
		return Totalprice;
	}
	public StringBuilder generateTicket() throws IOException  {
		Collections.sort(passenger,new PassengerComp());
		StringBuilder sb=new StringBuilder();
		sb.append("PNR       : "+generatePNR());
		sb.append("\nTrain No  : "+train.getTrainNo());
		sb.append("\nTrain Name  : "+train.getTrainName());
		sb.append("\nFrom :  "+train.getSource());
		sb.append("\nTo  : "+train.getDestination());
		sb.append("\nTravel Date    : "+travelDate);
		sb.append("\n");
		sb.append("\nPassengers  :     ");
		sb.append("\nName  \t"+" Age  "+"  Gender  "+" Fare ");

		for(Passenger p:passenger)
		{
			sb.append("\n"+p.getName()+"  "+p.getAge()+"  "+p.getGender());
			Double value=0.0;
			for(Double p1:passengers.values())
			{
				value=p1;
			}
			sb.append(" "+value);
		}
		
		sb.append("\nTotal Price: "+CalculateTotalTicketFare());
		//FileWriter file=new FileWriter("C:\\Users\\user52\\eclipse-workspace\\TrainTicket\\src\\main\\java\\sample.txt");
		//file.append("Hello");
		return sb;
	}
	public void writeTicket() throws IOException {
		String name=generatePNR();
		FileWriter file;
		File f=new File(name);
		String completePath="C:\\Users\\user52\\eclipse-workspace\\TrainTicket\\src\\main\\java\\"+f+".txt";
		file=new FileWriter(completePath);
		String ms1=generateTicket().toString();
		file.write(ms1);
		file.close();
	}
}
