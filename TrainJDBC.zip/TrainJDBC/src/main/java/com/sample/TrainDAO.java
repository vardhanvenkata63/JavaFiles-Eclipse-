package com.sample;

import org.springframework.jdbc.core.JdbcTemplate;

public class TrainDAO {
	private JdbcTemplate jdbctemplate;

	public JdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}

	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}
	
	public int insertTrain(Train t) {
		String query="insert into train values("+t.getTrainNo()+",'"+t.getTrainName()+"','"+t.getSource()+"','"+t.getDestination()+"',"+t.getTicketPrice()+")";
		return jdbctemplate.update(query);
	}
	public int updateTrain(Train t) {
		String query="update train set trainname = '"+t.getTrainName()+"',source='"+t.getSource()+"',destination='"+t.getDestination()+"',price="+t.getTicketPrice()+" where trainno="+t.getTrainNo();
		return jdbctemplate.update(query);
	}
	public int deleteTrain(Train t) {
		String query="delete from train where trainno = "+t.getTrainNo();
		return jdbctemplate.update(query);
	}
	
}
