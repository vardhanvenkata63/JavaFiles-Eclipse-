package com.example.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.example.bean.User;

public class UserDAO {
private JdbcTemplate jdbctemplate;
	
	public JdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}
	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}
	void setJdbcTemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate=jdbctemplate;
	}
	public int insertUser(User user) {
		String query="insert into users values("+user.getId()+",'"+user.getEmail()+"','"+user.getPassword()+"')";
		return jdbctemplate.update(query);
	}
	public int updateUser(User user) {
		String query="update Users set email = '"+user.getEmail()+"',password='"+user.getPassword()+"' where id ="+user.getId();
		return jdbctemplate.update(query);
	}
	public int deleteUser(int id) {
		String query="delete from users where id = "+id;
		return jdbctemplate.update(query);
	}
	public User getUserbyId(int id) {
		String query="select * from users where id=?";
		return jdbctemplate.queryForObject(query,new Object[] {id}, new BeanPropertyRowMapper<User>(User.class));
	}
	public List<User> getUsers(){
		return jdbctemplate.query("select * from users", new RowMapper<User>(){
			public User mapRow(ResultSet rs,int row) throws SQLException{
				User user=new User();
				user.setId(rs.getInt(1));
				user.setEmail(rs.getString(2));
				user.setPassword(rs.getString(3));
				return user;
			}
		});
	}
}
