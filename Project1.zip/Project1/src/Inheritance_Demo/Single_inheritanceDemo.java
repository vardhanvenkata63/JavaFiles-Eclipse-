package Inheritance_Demo;
class A1{
	int a=10;
}
class B1 extends A1{
	int b=20;
	int result;
	void add() {
		result=a+b;
		System.out.println("Sum of parent's attribute "+a+" and child's attribute "+b+" is: "+result);
	}
}
public class Single_inheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B1 b=new B1();
		System.out.println("Single Inheritance Demo");
		b.add();
	}

}
