package OOPSDemo;
class Student2{
	int rollno=101;
	String name="Vardhan";
	char sec='C';
	public void display() {
		System.out.println("ROll no:"+rollno+"\nName: "+name+"\nSection:"+sec);
	}
}
public class ClassWithMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student2 s1=new Student2();
		s1.display();
	}

}
