package GenericsDemo;

import java.util.TreeSet;

public class Demo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Integer> tr=new TreeSet<Integer>();
		tr.add(10);
		tr.add(20);
		tr.add(45);
		System.out.println(tr.size());
		System.out.println(tr.isEmpty());
		System.out.println(tr.first());
		System.out.println(tr.last());
		System.out.println(tr.contains(10));
		System.out.println(tr.contains(100));
		
	}

}
