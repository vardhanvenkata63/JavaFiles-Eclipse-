package Inheritance_Demo;
class X{
	int num1=100;
}
class Y extends X{
	int num2=300;
}
class Z extends Y{
	int num3=900;
	void add() {
		int result=num1+num2+num3;
		System.out.println("The sum of Grand parent's "+num1+" ,Parent's "+num2+" and child's "+num3+" is: "+result);
	}
}
public class Multilevel_InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Z z=new Z();
		System.out.println("Multi Level Inheritance Demo");
		z.add();
	}

}
