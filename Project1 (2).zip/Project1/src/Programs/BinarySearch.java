package Programs;

import java.util.Scanner;

public class BinarySearch {
	public static int binarysearch(int[] arr,int first,int last,int ele) {
		if(last>=first) {
		int mid=first+(last-first)/2;
		if(arr[mid]==ele) {
			return mid;
		}
		else if(arr[mid]>ele) {
			return binarysearch(arr,first,mid-1,ele);
		}
		else if(arr[mid]<ele) {
			return binarysearch(arr,mid+1,last,ele);
		}
	}
		return -1;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {10,20,30,60,80};
		int key;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter element to search");
		key=sc.nextInt();
		int index =	binarysearch(arr,0,arr.length,key);	
		if(index==-1) {
			System.out.println("Element not found");
		}
		else {
			System.out.println("Element found at "+index);
		}
		sc.close();
	}

}
