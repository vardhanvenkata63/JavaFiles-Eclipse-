
public class Test2 {

	public static void main(String[] args) {
		int id=101;
		double salary=100000.0;
		char willing='Y';
		boolean flag=true;
		String name="John";
		System.out.println("Employee Id(Integer value) "+id);
		System.out.println("Employee Name(String value) "+name);
		System.out.println("Employee Salary(Double value) "+salary);
		System.out.println("Employee willingness(character value) "+willing);
		System.out.println("Employee's willed(Boolean value) "+flag);
	}

}
