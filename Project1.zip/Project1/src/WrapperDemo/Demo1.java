package WrapperDemo;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=20;
		Integer number=num;
		System.out.println(num);
		System.out.println(number);
		Integer num1=Integer.valueOf(num);
		System.out.println(num1);
	}

}
