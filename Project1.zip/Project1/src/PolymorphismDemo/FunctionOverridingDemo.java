package PolymorphismDemo;
class Vehicle{
	void move() {
		System.out.println("\nThe vehicle has a property of moving");
	}
}
class Car extends Vehicle{
	void move() {
		System.out.println("\nThe car will move by using diesel");
	}
}
class Bike extends Vehicle{
	void move() {
		System.out.println("\nThe bike will move by using petrol");
	}
}
public class FunctionOverridingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("The overriding demo\n->It will change the parent method the method wll have same method declaration as parent\n");
		Bike b=new Bike();
		b.move();
		
		Vehicle v=new Vehicle();
		v.move();
		
		Car c=new Car();
		c.move();
	}

}
