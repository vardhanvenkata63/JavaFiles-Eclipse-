package OOPSDemo;
class Student{
	int rollno=101;
	String name="Vardhan";
	char sec='C';
}

public class AccesswithObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student();
		System.out.println(s1.rollno);
		System.out.println(s1.name);
		System.out.println(s1.sec);
		
	}

}
