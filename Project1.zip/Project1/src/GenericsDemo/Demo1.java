package GenericsDemo;
class A<T>{
	T i;
	A(T val){
		this.i=val;
	}
	T getObject() {
		return this.i;
	}
}
public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A<Integer> obj1=new A<Integer>(12);
		System.out.println(obj1.getObject());
		A<String> obj2=new A<String>("vardhan");
		System.out.println(obj2.getObject());
		A<Character> obj3=new A<Character>('d');
		System.out.println(obj3.getObject());
		A<Double> obj4=new A<Double>(1200000.80);
		System.out.println(obj4.getObject());
		A<Boolean> obj5=new A<Boolean>(true);
		System.out.println(obj5.getObject());
		
 	}

}
