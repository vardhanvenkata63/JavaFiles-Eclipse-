package OOPSDemo;
class Sample1{
	int sid=87;
	char flag='M';
	Sample1(){
		System.out.println("Default Constructor");
	}
	Sample1(int sid,char flag){
		System.out.println("Parameterised Constructor");
		this.sid=sid;
		this.flag=flag;
	}
	void display() {
		System.out.println("Sample id:"+this.sid+"\nSample flag:"+this.flag+"\n");
	}
}

public class ParameterisedConstructorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample1 s1=new Sample1(11,'Y');
		s1.display();
		Sample1 s2=new Sample1(90,'N');
		s2.display();
		Sample1 s3=new Sample1();
		s3.display();
	}

}
