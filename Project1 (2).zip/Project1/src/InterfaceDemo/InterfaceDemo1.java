package InterfaceDemo;
interface I1{
	void display();
}
interface I2{
	void calcuate();
}
public class InterfaceDemo1 implements I1,I2{
	
	public static void main(String[] args) {
		InterfaceDemo1 i=new InterfaceDemo1();
		i.calcuate();
		i.display();
	}

	@Override
	public void calcuate() {
		System.out.println("Message from calculate");
	}

	@Override
	public void display() {
		System.out.println("Message from display");
	}

}
