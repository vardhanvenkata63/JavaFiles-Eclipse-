package Operators_Demo;

public class Test5 {

	public static void main(String[] args) {
		//ternary opearator (condition)?res1 :res2
		int a=10;
		int b=20;
		//the res will contain 20 because the conditon is not satisfied
		int res=(a > b)?a:b;
		//the res1 will contain 10 because the condition is met
		int res1=(a < b)?a:b;
		System.out.println(res);
		System.out.println(res1);
	}

}
