package OOPSDemo;
class Student1{
	private int rollno;
	private String name;
	private char sec;

	public Student1(int rollno,String name,char sec){
	this.rollno=rollno;
	this.name=name;
	this.sec=sec;
	}
	public int getRollno() {
		return this.rollno;
	}
	public String getName() {
		return this.name;
	}
	public char getSec() {
		return this.sec;
	}
}

public class GetSetDemo {

	public static void main(String[] args) {
		Student1 s1=new Student1(101,"Vardhan",'C');
		System.out.println(s1.getRollno());
		System.out.println(s1.getName());
		System.out.println(s1.getSec());
		Student1 s2=new Student1(102,"Venkata",'B');
		System.out.println(s2.getRollno());
		System.out.println(s2.getName());
		System.out.println(s2.getSec());
	}

}