package IOJavaDemo;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONObject;

public class FileWriterJSON1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String msg="I Inserted text using File Writer";
		FileWriter f;
		try {
			f = new FileWriter("C:\\Users\\user52\\eclipse-workspace\\Project1\\src\\IOJavaDemo\\SampleFile1");
			JSONObject obj=new JSONObject();
			JSONObject obj1=new JSONObject();
			obj.put("id",101);
			obj.put("Name", "vardhan");
			obj.put("age", 21);
			obj1.put("id", 102);
			obj1.put("Name","Juila");
			obj1.put("age", 50);
			f.write(obj.toJSONString()+"\n"+obj1.toJSONString());
			f.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Done...");
	}

}
