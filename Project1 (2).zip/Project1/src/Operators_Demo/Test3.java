package Operators_Demo;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=982;
		int num2=838;
		System.out.println(num1+" is greater than "+num2 +"? "+(num1 > num2));
		System.out.println(num1+" is less than "+num2 +"? "+(num1 < num2));
		int n1=10,n2=30;
		System.out.println(n1+" is greater than "+n2 +"? "+(n1 > n2));
		System.out.println(n1+" is less than "+ n2 +"? "+(n1 < n2));
	}

}
