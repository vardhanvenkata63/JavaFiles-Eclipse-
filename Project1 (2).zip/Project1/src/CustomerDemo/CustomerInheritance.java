package CustomerDemo;
class Customer1{
	String name="Vardhan";
	int balance=10000;
}
class Demo extends Customer1{
	public void withdrawAmount(int amount) {
		System.out.println(amount+" is withdrawn from "+balance);
		balance = balance-amount;
		
	}
	public void checkBalance() {
		System.out.println("Remaining Balance: "+balance);
	}
}
public class CustomerInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo d=new Demo();
		d.checkBalance();
		d.withdrawAmount(300);
		d.checkBalance();
	}

}
