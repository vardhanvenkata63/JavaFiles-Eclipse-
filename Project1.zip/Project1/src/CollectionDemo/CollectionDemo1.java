package CollectionDemo;

import java.util.ArrayList;

public class CollectionDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> a=new ArrayList<String>();
		a.add("abc");
		a.add("xyz");
		System.out.println(a.get(1));
	}

}
