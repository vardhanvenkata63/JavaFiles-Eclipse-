package CollectionDemo;
import java.util.ArrayList;
public class CollectionDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList a=new ArrayList();
		a.add(101);
		a.add("Vardhan");
		a.add(29000);
		a.add(10.099);
		for(int i=0;i<a.size();i++) {
			System.out.println(a.get(i));
		}
	}

}
