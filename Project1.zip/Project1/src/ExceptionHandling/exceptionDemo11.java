package ExceptionHandling;

public class exceptionDemo11 {
	static void task() throws NullPointerException{
		System.out.println("With in task");
		throw new NullPointerException("No value Present");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			task();
		}
		catch(NullPointerException e) {
			System.out.println(e.getMessage());
		}
	}

}
