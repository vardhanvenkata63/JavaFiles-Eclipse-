package ExceptionHandling;

public class exceptionDemo9 {
	static boolean checkNumber(int n) {
		if(n==0) {
			throw new ArithmeticException("Divide By Zero Error");
		}else {
			return true;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=200;
		int num2=0;
		int result;
		System.out.println(1);
		try {
			if(checkNumber(num2)) {
				result=num1/num2;
				System.out.println("Divison of 2 numbers is"+result);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		System.out.println(2);
	}

}
