
public class Test3 {

	public static void main(String[] args) {
		int marks[]= {10,34,78,43,32};
		System.out.println("Marks of 3rd person is "+marks[2]);
	}

}
