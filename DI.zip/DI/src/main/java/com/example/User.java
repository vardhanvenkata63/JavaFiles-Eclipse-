package com.example;

public class User {
	private String username;
	private String password;
	private int id;
	public User() {
		System.out.println("Default Constructor Invoked");
	}
	public User(String username,String password,int id) {
		this.username=username;
		this.password=password;
		this.id=id;
	}
	void display() { 
		System.out.println("Username is : "+username+"\nPassword is : "+password+"\nId is: "+id);
	}
	/**
	public void setUsername(String username) {
		this.username=username;
	}
	*/
}

