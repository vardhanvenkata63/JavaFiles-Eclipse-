package CustomerDemo;
class NormalCustomer{
	int cusbal;
	void creditBalance(int balance){
		cusbal=balance;
	}
	void display() {
		if(cusbal<5000) {
			System.out.println("\nI am a normal Customer i will have balance less than 5000");
			System.out.println("My Balance is: "+cusbal);
		}
		else {
			premiumCustomer preCustomer = new premiumCustomer();
			preCustomer.creditBalance(cusbal);
			preCustomer.display();
		}
	
	}
}
class premiumCustomer extends NormalCustomer{
	int cusbal;
	void creditBalance(int balance){
		cusbal=balance;
	}
	void display() {
		if(cusbal>5000) {
		System.out.println("\nI am a premium Customer i will have a balance grater than 5000");
		System.out.println("My Balance is: "+cusbal);
		}
		else {
			NormalCustomer normalCustomer = new NormalCustomer();
			normalCustomer.creditBalance(cusbal);
			normalCustomer.display();
		}
	}
}
public class customerPolymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		premiumCustomer c=new premiumCustomer();
		c.creditBalance(7000);
		c.display();
		
		premiumCustomer c1=new premiumCustomer();
		c1.creditBalance(3000);
		c1.display();
		
		NormalCustomer n=new NormalCustomer();
		n.creditBalance(2500);
		n.display();
		
		NormalCustomer n1=new NormalCustomer();
		n1.creditBalance(8000);
		n1.display();
	}

}
