package CustomerDemo;

public class CustomerEncapsulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c=new Customer();
		c.setCustomerId(6111);
		c.setCustomerName("Venkata Merapureddy");
		c.setCustomerBalance(100000);
		
		Customer c1=new Customer();
		c1.setCustomerId(6156);
		c1.setCustomerName("Harsha Apoorv");
		c1.setCustomerBalance(100);
		
		System.out.println("Customer Id: "+c.getCustomerId()+"\n Customer Name: "+c.getCustomerName()+"\n Customer Wallet Balance: "+c.getCustomerBalance());
		System.out.println("\nCustomer Id: "+c1.getCustomerId()+"\n Customer Name: "+c1.getCustomerName()+"\n Customer Wallet Balance: "+c1.getCustomerBalance());
		
	}

}
