package com.example;
class Cal{
	public static int addition(int a,int b) {
		return a+b;
	}
}
public class Demo1 extends Cal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cal c=new Cal();
		System.out.println("Sum of 2 numbers is: "+c.addition(20,40));
	}	

}
