package Programs;

import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String str=sc.next();
		String revstr="";
		for(int i=(str.length()-1);i>=0;i--) {
			revstr=revstr+str.charAt(i);
		}
		System.out.println("Your string is: "+str);
		System.out.println("The Reverse String is:"+revstr);
		sc.close();
	}

}
