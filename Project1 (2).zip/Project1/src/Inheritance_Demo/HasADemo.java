package Inheritance_Demo;

public class HasADemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
