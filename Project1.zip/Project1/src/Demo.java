class TwoMainMethodDemo {
	static int a,b;
	public void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Using Class main with String args");
		a=40;
		b=50;
		System.out.println("product is:"+a*b);
	}
	public  void main(int args) {
		System.out.println("Using Class main with int args");
		a=10;
		b=20;
		System.out.println("Product is:"+a*b);
	}
}
class Demo{
	public static void main(String [] args) {
		TwoMainMethodDemo obj1=new TwoMainMethodDemo();
		obj1.main(1);
		obj1.main(null);
		//TwoMainMethodDemo.main(1);
		//TwoMainMethodDemo.main(null);
	}
}
