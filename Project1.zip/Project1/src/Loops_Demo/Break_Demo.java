package Loops_Demo;

public class Break_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<20;i++) {
			if(i==7)
					break;
			System.out.println(i);
		}
	}

}
