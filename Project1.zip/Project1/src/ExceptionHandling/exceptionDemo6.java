package ExceptionHandling;

public class exceptionDemo6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=40;
		String name=null;
		int[] numbers= {30,40,80,90,67};
		try {
			System.out.println(name.length());
			System.out.println(numbers[6]);
			System.out.println(num/0);
		}
		catch(NullPointerException e1) {
			System.out.println("I am NUll");
			System.out.println(e1);
		}
		catch(ArithmeticException e2) {
			System.out.println(num/(0+1));
		}
		catch(ArrayIndexOutOfBoundsException e3) {
			System.out.println("Exception Occured "+e3);
		}
		catch(Exception ex) {
			System.out.println("Excpetion occured"+ex);
		}
	}

}
