package IOJavaDemo;

import java.io.IOException;
import java.io.InputStreamReader;

public class InputStreamReaderDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//InputStreamReader ip=new InputStreamReader(System.in);
		System.out.println("Enter the Characteres '0' to Quit");
		char c;
		do {
			InputStreamReader ip=new InputStreamReader(System.in);
			c=(char)ip.read();
			System.out.println("Entered character is:"+c);
		}while(c!='0');
	}	

}
