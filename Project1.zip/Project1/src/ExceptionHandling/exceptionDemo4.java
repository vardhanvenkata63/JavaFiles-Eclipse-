package ExceptionHandling;

public class exceptionDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=20;
		String name=null;
		try {
			System.out.println(num/0);
			//the next statement is not executed at all because whenever an exception occurs the flow will go to the according catch block
			System.out.println(name.length());
		}
		catch(NullPointerException ex) {
			System.out.println("I am null exception handler");
			System.out.println(ex);
		}
		catch(ArithmeticException ex1) {
			System.out.println("I am arithmetic exception");
			System.out.println(ex1.getMessage());
			System.out.println(ex1.toString());
		}
	}

}
