package Programs;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number;
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter Number:");
		number=scr.nextInt();
		int count=0;
		for(int i=2;i<=number;i++)
		{
			if(number%i==0)
				count++;
		}
		if(count==1)
			System.out.println("Entered Number is Prime");
		else
			System.out.println("Entered Number is Not Prime");
		scr.close();
	}

}
