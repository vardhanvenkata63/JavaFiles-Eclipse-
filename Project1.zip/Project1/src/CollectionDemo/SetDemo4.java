package CollectionDemo;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class SetDemo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> s1=new HashSet<Integer>();
		s1.addAll(Arrays.asList(new Integer[] {1,2,3,4,5,6,7,8,9}));
		
		Set<Integer> s2=new HashSet<Integer>();
		s2.addAll(Arrays.asList(new Integer[] {8,9,90,7,45}));
		
		System.out.println("Set 1 values:\n"+s1);
		System.out.println("------------------");
		System.out.println("Set 2 values:\n"+s2);
		System.out.println("------------------");
		Set<Integer> union=new HashSet<Integer>(s1);
		union.addAll(s2);
		System.out.println("Union of set1 and set2 is");
		System.out.println(union);
		System.out.println("------------------");
		System.out.println("intersection of set1 and set2 is");
		Set<Integer> intersection=new HashSet<Integer>(s1);
		intersection.retainAll(s2);
		System.out.println(intersection);
		System.out.println("------------------");
		System.out.println("difference of set1 and set2 is(set1-set2)");
		Set<Integer> diff1=new HashSet<Integer>(s1);
		diff1.removeAll(s2);
		System.out.println(diff1);
		System.out.println("------------------");
		System.out.println("difference of set2 and set1 is(set2-set1)");
		Set<Integer> diff2=new HashSet<Integer>(s2);
		diff2.removeAll(s1);
		System.out.println(diff2);
	}

}
