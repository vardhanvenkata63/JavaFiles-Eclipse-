package GenericsDemo;

import java.util.ArrayList;

public class Demo4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> arr=new ArrayList<String>();
		arr.add("Vardhan");
		arr.add("venkata");
		arr.add("durga");
		//arr.add(10);
		//Here the collections has a generic template of string so we cannot add integer to a string value
		System.out.println(arr.get(0));
		System.out.println("Printing using for each");
		//Printing using for each
		for(String i: arr) {
			System.out.println(i);
		}
	}

}
