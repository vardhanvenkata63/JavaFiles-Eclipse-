package IOJavaDemo;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
public class InputStreamDemoforFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InputStream ip=null;
		try {
			ip=new FileInputStream("C:\\Users\\user52\\eclipse-workspace\\Project1\\src\\IOJavaDemo\\Hello");
			int i;
			while((i=ip.read())!=-1) {
				System.out.print((char)i);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
