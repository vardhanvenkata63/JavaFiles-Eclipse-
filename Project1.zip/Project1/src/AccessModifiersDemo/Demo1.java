package AccessModifiersDemo;

public class Demo1 {
	int number=100;
	static int number1=200;
	private int number2=300;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo1 d=new Demo1();
		//we can access the variable which is outside main method using an object 
		//because we cannot a non static variable from static reference
		System.out.println(d.number);
		//We can access the variable if its declared as static.
		System.out.println(number1);
	}

}
