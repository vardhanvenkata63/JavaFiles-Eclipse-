package ExceptionHandling;
class A1{
	int num;
	A1(int num){
		this.num=num;	
	}
	void display() {
		System.out.println("Number is: "+num);
	}
}
class B1 extends A1{
	B1(int num){
		super(num);
	}
	void display() {
		System.out.println("Number is:"+num+" from clss B1");
	}
}
public class exceptionDemo8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B1 b=new B1(20);
		A1 a=new A1(40);
		
		try {
			A1 obj=new A1(90);
			B1 obj1=(B1)obj;
		}catch(Exception e) {
			System.out.println(e);
		}finally {
			System.out.println("This will execute everytime");
		}
	}

}
