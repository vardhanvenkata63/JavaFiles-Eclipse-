package Programs;

import java.util.Scanner;

public class Tables1_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		for(int num=1;num<=10;num++) {
			for(int i=1;i<=10;i++) {
				System.out.println(num+" * "+i+" = "+num*i);
			}
			System.out.println("----------------------------");
			System.out.println("Press y to continue and e to exit");
			
			char ch=sc.next().charAt(0);
			if(ch=='e') 
				break;
		}
		sc.close();
	}

}
