package EncapsulationDemo;

public class EncapsulationDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product p=new Product();
		p.setProductId(101);
		p.setProductName("Dell laptop");
		p.setPrice(45000);
		
		Product p1=new Product();
		p1.setProductId(110);
		p1.setProductName("Lenovo Keyboard");
		p1.setPrice(300);
		
		System.out.println("Product Id: "+p.getProductId()+"\nProduct Name: "+p.getProductName()+"\nProduct Price: "+p.getPrice());
		System.out.println("\nProduct Id: "+p1.getProductId()+"\nProduct Name: "+p1.getProductName()+"\nProduct Price: "+p1.getPrice());
	}

}
