package GenericsDemo;
class Employee<T1,T2>{
	T1 val1;
	T2 val2;
	Employee(T1 p1,T2 p2){
		this.val1=p1;
		this.val2=p2;
	}
	void display() {
		System.out.println("First parameter : "+this.val1);
		System.out.println("Second parameter : "+this.val2);
	}
}
public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee<Integer,String> obj1=new Employee<Integer,String>(101,"vardhan");
		obj1.display();
		Employee<Integer,String> obj2=new Employee<Integer,String>(102,"venkata");
		obj2.display();
		
	}

}
