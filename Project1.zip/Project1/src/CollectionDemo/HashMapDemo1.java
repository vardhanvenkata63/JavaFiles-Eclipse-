package CollectionDemo;

import java.util.HashMap;

public class HashMapDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> h1=new HashMap<Integer,String>();
		h1.put(101,"vardhan");
		h1.put(102, "shraadha");
		h1.put(103, "harsha");
		h1.put(104, "siren");
		h1.put(105, "roshini");
		System.out.println(h1.get(104));
		System.out.println(h1.values());
		System.out.println(h1.keySet());
		System.out.println(h1.keySet().contains(104));
		System.out.println(h1.containsKey(103));
		System.out.println(h1.containsKey(108));
		System.out.println(h1.containsValue("vardhan"));
		System.out.println(h1.containsValue("venkat"));
	}
}
