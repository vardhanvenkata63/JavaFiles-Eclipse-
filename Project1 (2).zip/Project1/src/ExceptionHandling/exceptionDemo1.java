package ExceptionHandling;

public class exceptionDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(1);
		System.out.println(2);
		System.out.println(3);
		System.out.println(4);
		//System.out.println(5/0);
		//THe above line will give an runtime error(Exception)
		//WE can handle that by using try catch block
		try {
			System.out.println(5/0);
		}
		catch(Exception ex){
			System.out.println(5/1);	
		}
		System.out.println(6);
	}

}
