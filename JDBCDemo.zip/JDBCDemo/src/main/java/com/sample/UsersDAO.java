package com.sample;

import org.springframework.jdbc.core.JdbcTemplate;

public class UsersDAO {
	private JdbcTemplate jdbctemplate;
	
	public JdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}
	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}
	void setJdbcTemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate=jdbctemplate;
	}
	public int insertUser(Users user) {
		String query="insert into users values("+user.getId()+",'"+user.getEmail()+"','"+user.getPassword()+"')";
		return jdbctemplate.update(query);
	}
	public int updateUser(Users user) {
		String query="update Users set email = '"+user.getEmail()+"',password='"+user.getPassword()+"' where id ="+user.getId();
		return jdbctemplate.update(query);
	}
	public int deleteUser(Users user) {
		String query="delete from users where id = "+user.getId();
		return jdbctemplate.update(query);
	}
}
