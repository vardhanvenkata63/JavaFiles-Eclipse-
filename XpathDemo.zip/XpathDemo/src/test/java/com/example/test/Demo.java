package com.example.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Demo {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\user52\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver test=new ChromeDriver();
		//test.manage.window.maximize();
		test.get("https://www.google.co.in/");
		test.findElement(By.name("q")).sendKeys("Soap UI tutorial");
		//Demo obj=new Demo();
		WebElement Demo = test.findElement(By.tagName("input"));
		System.out.println(test);
		System.out.println(Demo);
//		System.out.println(Demo.getAttribute("input"));
	}
}
