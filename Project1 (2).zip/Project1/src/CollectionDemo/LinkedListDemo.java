package CollectionDemo;

import java.util.LinkedList;

import java.util.Iterator;

public class LinkedListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer> l=new LinkedList<Integer>();
		l.add(10);
		l.add(80);
		l.add(67);
		l.add(6111);
		Iterator it=l.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
