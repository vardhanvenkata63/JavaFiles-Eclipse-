package CollectionDemo;

import java.util.ArrayList;
import java.util.Iterator;

public class CollectionDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> a=new ArrayList<Integer>();
		a.add(101);
		a.add(156);
		a.add(456);
		a.add(199);
		
		Iterator it=a.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
