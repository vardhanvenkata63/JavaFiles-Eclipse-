package Programs;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number;
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter Number:");
		number=scr.nextInt();
		int revnum=0;
		int n1=number;
		while(n1!=0) {
			int digit=n1%10;
			revnum=revnum*10+digit;
			n1=n1/10;
		}
		System.out.println("Your Number is:"+number);
		System.out.println("Reversed Number is:"+revnum);
		scr.close();
	}

}
