package EncapsulationDemo;

public class User {
		private String username;
		private String password;
		public String getUserName() {
			return username;
		}
		public String getPassword() {
			return password;
		}
		public void setUserName(String UserName) {
			this.username=UserName;
		}
		public void setPassword(String pwd) {
			this.password=pwd;
		}
}
