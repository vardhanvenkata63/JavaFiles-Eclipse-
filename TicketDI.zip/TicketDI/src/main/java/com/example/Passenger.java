package com.example;

public class Passenger {
	//Plain Object Java Object(POJO)
	//POJO means it will have private attributes,constructor,getter and setters.
	private String name;
	private int age;
	private char gender;
	public Passenger() {
		System.out.println("Default Constructor");
	}
	public Passenger(String name,int age,char gender) {
		this.name=name;
		this.age=age;
		this.gender=gender;
	}
	public void display() {
		System.out.println("Passenger Name : "+name);
		System.out.println("Passenger Age : "+age);
		System.out.println("Passenger Gender : "+gender+" \n");
	}
}
