package com.test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.example.*;
public class TestAdd {
	@Before
	public void beforeTest() {
		System.out.println("Executed Before Every Test");
	}
	
	@Test
	public void testAdd() {
		System.out.println("The Test 1");
		assertEquals(60,Demo1.addition(40,20));
		//assertEquals(40,Demo1.addition(20, 30));
		//assertNotEquals(60,Demo1.addition(40,20));
		assertNotEquals(40,Demo1.addition(20, 30));
	}
	@Test
	public void testAdd1() {
		System.out.println("The Test 2");
		assertEquals(40,Demo1.addition(20, 20));
	}
	@After
	public void afterTest() {
		System.out.println("Executed after every test");
	}
}
