package AbstractionDemo;
abstract class sample{
	int num=100;
	abstract void display();
	abstract void calculate();
	void sam() {
		System.out.println("\nAbstract class can have concrete methods also");
	}
}
public class AbstractionDemo2 extends sample{

	public static void main(String[] args) {
		AbstractionDemo2 a=new AbstractionDemo2();
		a.display();
		a.calculate();
		a.sam();
	}

	@Override
	void display() {
		System.out.println("I am an abstract method implemented in the child class");
		System.out.println("I wil just diplay only the number is: "+num);
	}

	@Override
	void calculate() {
		System.out.println("\nI am an abstract method implemented in the child class");
		System.out.println("Here i will perform calucaltion also");
		System.out.println("the number gets multlied by 200"+num*200);
	}

}
