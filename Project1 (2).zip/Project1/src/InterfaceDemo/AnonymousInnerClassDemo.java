package InterfaceDemo;
interface Add{
	void addition(int a,int b);
}
public class AnonymousInnerClassDemo{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//The below is an anonymous inner class because it don't have any class.
		//for sake of implementing the interface method we have instantiated the object like that.
		Add obj=new Add() {
			@Override
			public void addition(int a, int b) {
				// TODO Auto-generated method stub
				System.out.println("Sum of "+a+" and "+b+" is "+(a+b) );
			}
		};
		obj.addition(200,300);
	}
}