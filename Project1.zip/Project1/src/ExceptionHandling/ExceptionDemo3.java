package ExceptionHandling;

public class ExceptionDemo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=30;
		try {
			System.out.println(num/0);
		}
		catch(NullPointerException ex) {
			System.out.println("I am null i will be invoked when any null comes");
			System.out.println(ex);
		}
		catch(ArithmeticException ex1) {
			System.out.println(num/(0+1));
		}
	}

}
