package OOPSDemo;
class Sample{
	Sample(){
		System.out.println("Default Constructor invoked");
	}
	void display(){
		System.out.println("The default constructor is invoked when we create or instantiate a class\n");
	}
}

public class DefaultConstructorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample s1=new Sample();
		s1.display();
		Sample s2=new Sample();
		s2.display();
	}

}
