package Arrays_Demo;

public class Array_Enhanced {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,20,303};
		for(int i: a) {
		System.out.println(i);
		}
	}

}
