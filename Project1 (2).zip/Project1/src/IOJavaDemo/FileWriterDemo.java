package IOJavaDemo;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String msg="I Inserted text using File Writer";
		FileWriter f;
		try {
			f = new FileWriter("C:\\Users\\user52\\eclipse-workspace\\Project1\\src\\IOJavaDemo\\Sample");
			f.write(msg);
			f.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Done...");
	}
}
