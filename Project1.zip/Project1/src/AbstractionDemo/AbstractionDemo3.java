package AbstractionDemo;
abstract class Shape{
	int l;
	int b;
	Shape(int l,int b){
		this.l=l;
		this.b=b;
	}
	abstract void calculateArea();
}
class Triangle extends Shape{
	Triangle(int l,int b){
		super(l,b);
	}
	void calculateArea() {
		double res=(float)(1/2f)*l*b;
		System.out.println("The Area of the Traingle is: "+res);
	}
}
class Rectangle extends Shape{
	Rectangle(int l, int b) {
		super(l, b);
	}

	@Override
	void calculateArea() {
	double res=l*b;
	System.out.println("The Area of the Rectangle is: "+res);
	}

		
}
public class AbstractionDemo3 {

	public static void main(String[] args) {
		Triangle t=new Triangle(30,67);
		t.calculateArea();
		
		Rectangle r=new Rectangle(45,14);
		r.calculateArea();
	}

}
