package CollectionDemo;

import java.util.Iterator;
import java.util.PriorityQueue;

public class PriorityQueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue<Integer> p1=new PriorityQueue<Integer>();
		p1.add(89);
		p1.add(90);
		p1.add(24);
		p1.add(6);
		Iterator it=p1.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("---------------");
		System.out.println("THe Remove method will remove the head of the queue it will RaiseException if the queue is empty"+p1.remove());
		System.out.println("THe poll method will remove the head of the queue it will ReturnNull if the queue is empty"+p1.poll());
		Iterator it1=p1.iterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
	}

}
