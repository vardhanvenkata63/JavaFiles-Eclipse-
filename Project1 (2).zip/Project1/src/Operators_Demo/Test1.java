package Operators_Demo;

public class Test1 {

	public static void main(String[] args) {
		int a=150;
		int b=100;
		System.out.println(a+" + "+b+" is: "+(a+b));
		System.out.println(a+" - "+b+" is: "+(a-b));
		System.out.println(a+" / "+b+" is: "+(a/b));
		System.out.println(a+" * "+b+" is: "+(a*b));
		System.out.println(a+" % "+b+" is: "+(a%b));
	}

}
