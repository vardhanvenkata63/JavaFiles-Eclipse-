package Arrays_Demo;

public class NormalArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,20,303};
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		System.out.println(a[3]);
	}

}
