package ExceptionHandling;
class InvalidUserException extends Exception{
	public InvalidUserException(String msg) {
		super(msg);
	}
}
public class CustomExceptionDemo {
	static void validateUser(String username,String pwd) throws InvalidUserException{
		if(username.equals("admin") && pwd.equals("root")) {
			System.out.println("Valid User");
		}
		else {
			throw new InvalidUserException("Invalid User");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			validateUser("admin","admin123");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
