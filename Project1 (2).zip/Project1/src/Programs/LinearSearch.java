package Programs;
import java.util.Scanner;
public class LinearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {10,565,56,45,90,65};
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println("\nEnter Element to find index:");
		Scanner sc=new Scanner(System.in);
		int number=sc.nextInt();
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==number)
				System.out.println("The "+number+" is at "+i);
		}
		sc.close();
	}

}
