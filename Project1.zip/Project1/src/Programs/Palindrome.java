package Programs;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String str=sc.next();
		String revstr="";
		for(int i=(str.length()-1);i>=0;i--) {
			revstr=revstr+str.charAt(i);
		}
		if(str.equals(revstr))
				System.out.println("Entered String is a Palindrome");
		else
			System.out.println("It is not a Palindrome");
		sc.close();
	}

}
