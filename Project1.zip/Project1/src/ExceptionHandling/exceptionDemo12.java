package ExceptionHandling;

import java.util.Scanner;

public class exceptionDemo12 {
	static boolean checkMark(int m) {
		if(m<0) {
			throw new ArithmeticException("Please Enter a valid mark");
		}
		else {
			return true;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter mark");
		int m=sc.nextInt();
		System.out.println(1);
		try {
			if(checkMark(m)) {
				System.out.println("Entered mark is:"+m);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println(2);
		sc.close();
	}

}
