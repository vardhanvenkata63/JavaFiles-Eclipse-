package Inheritance_Demo;
class L{
	int num1=10;
}
class M extends L{
	int num2=20;
	int res;
	void cal() {
		res=num1+num2;
		System.out.println(res);
	}
}
class N extends L{
	int num2=30;
	int res;
	void cal() {
		res=num1*num2;
		System.out.println(res);
	}
}
class O extends N{
	void display() {
		System.out.println("Message from Class O");
		cal();
	}
}
public class Hybrid_InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hybrid Inheritance Demo");
		O o=new O();
		o.display();
	}

}
