package Operators_Demo;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=143;
		int num1=246;
		System.out.println("Before :"+num+" after Number incremented with post increment" + num++);
		System.out.println("Before :"+num1+" after Number decremented with post decrement" + num1--);
		System.out.println("Before :"+num+" after Number incremented with pre increment" + ++num);
		System.out.println("Before: "+num1+" after Number decremented with pre decrement" + num1--);
	}

}
